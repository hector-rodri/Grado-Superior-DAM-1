//HÉCTOR RODRÍGUEZ LOZANO
package es.cide.dam.programacio.yaaz;//Paquete de la clase

public class superZombie extends zombie {//Clase hija de zombie

    public superZombie() {//Constructor de la clase
        super(60, 10, 5);//Llamada al constructor de la clase padre

    }

}
