package es.cide.dam.programacio.yaaz;//HÉCTOR RODRÍGUEZ LOZANO

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("HOLA! BENVINGUT A AQUEST JOC.");
        System.out.println("ABANS DE COMENÇAR OMPLE AIXÒ:");
        System.out.println("QUIN VOLS QUE SIGUI EL NOM DE LA CIUTAT?");
        String nomCiutatUsuari = sc.nextLine();
        System.out.println("QUIN VOLS QUE SIGUI EL NOM DEL SUPERVIVENT?");
        String nomSupervivientUsuari = sc.nextLine();
        System.out.println("QUIN TAMANY VOLS QUE TENGUI LA CIUTAT? (10 o 20 aconsejable)");
        int tamanyCiutatUsuario = sc.nextInt();

        System.out.println(
                "▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄");

        //INDICE
        ciutat ciutat1 = new ciutat(nomCiutatUsuari, tamanyCiutatUsuario);//Ciudad creada con el nombre y tamaño introducido por el usuario.
        supervivient supervivient1 = new supervivient(nomSupervivientUsuari);//Superviviente creado con el nombre introducido por el usuario.
        zombie zombie1 = new zombie();//Zombie creado.
        String nomCiutat = ciutat1.getNom();//Método para saber el nombre de la ciudad.
        String nomSupervivient = supervivient1.getNom();//Método para saber el nombre del superviviente.
        int salutSupervivient = supervivient1.getSalut();//Método para saber la salud del superviviente.
        int salutZombie = zombie1.getSalut();//Método para saber la salud del zombie.
        int atacaSupervivient = supervivient1.ataca();//Método para atacar y saber el valor del ataque realizado por el superviviente.
        int defensaZombie = zombie1.defensat();//Método para defender y saber el valor de la defensa realizada por el zombie.
        int atacaZombie = zombie1.ataca();//Método para atacar y saber el valor del ataque realizado por el zombie.
        int defensaSupervivient = supervivient1.defensat();//Método para defender y saber el valor de la defensa realizada por el superviviente.
        int puntsPerdutsZombie = atacaSupervivient - defensaZombie;//Variable para recoger los puntos perdidos del zombie en el combate.
        int puntsPerdutsSupervivient = atacaZombie - defensaSupervivient;//Variable para recoger los puntos perdidos del superviviente en el combate.

        ciutat1.getNom();
        System.out.println("Benvingut a " + nomCiutat);
        supervivient1.getNom();
        System.out.println(
                "El nostre protagonista " + nomSupervivient + " es troba en un univers destruit i apocaliptic.");
        System.out.println(
                "El nostre heroi recorrera la ciutat, ubicació per ubicació per tal de lluitar per la seva vida.");
        

        for (int i = 0; i < tamanyCiutatUsuario; i++) {

            zombie1 = ciutat1.posicioRuta(i);
            salutZombie = zombie1.getSalut();
            
            if (i==1 && salutSupervivient >= 0) {
                System.out.println("Després d'aquest primer combat "+nomSupervivient+" es conscient del perill d'aquesta ciutat catastròfica.");
            }
            
            System.out.println(nomSupervivient + " ha trobat un zombie!");

            while (salutSupervivient > 0 && salutZombie > 0) {

                atacaSupervivient = supervivient1.ataca();
                System.out.println(nomSupervivient+" ataca amb " + atacaSupervivient + " punts de atac.");
                if (atacaSupervivient == 0) {
                    System.out.println(nomSupervivient + " f**ck he fallado mi ataque!");
                }

                defensaZombie = zombie1.defensat();
                System.out.println("El zombie es defensa amb " + defensaZombie + " punts de defensa.");

                atacaZombie = zombie1.ataca();
                System.out.println("El zombie ataca amb " + atacaZombie + " punts de atac!");
                if (atacaZombie == 0) {
                    System.out.println(nomSupervivient + " celebra que no li ha donat el atac del zombie!");

                }

                defensaSupervivient = supervivient1.defensat();
                System.out.println(nomSupervivient+" es defensa amb " + defensaSupervivient + " punts de defensa.");

                puntsPerdutsZombie = atacaSupervivient - defensaZombie;
                if (puntsPerdutsZombie > 0) {
                    zombie1.setSalut(salutZombie = salutZombie - puntsPerdutsZombie);
                    System.out.println("·El zombie te " + salutZombie + " punts de salut.");
                }

                puntsPerdutsSupervivient = atacaZombie - defensaSupervivient;
                if (puntsPerdutsSupervivient > 0) {
                    supervivient1.setSalut(salutSupervivient = salutSupervivient - puntsPerdutsSupervivient);
                    System.out.println("·El supervivient te " + salutSupervivient + " punts de salut.");
                }

                if (salutSupervivient > 0 && salutZombie > 0) {
                    System.out.println(
                            "----------------------------------------------------NEXT ROUND----------------------------------------------------");
                }

                if (salutZombie <= 0) {
                    System.out.println(nomSupervivient + " ha destrozat al zombie!!!");
                    System.out.println(
                            "-----------------------------ZOMBIE " + (i + 1) + " IS DEAD-----------------------------");

                }

                if (salutSupervivient <= 0) {
                    System.out.println(nomSupervivient + " ha mort pel zombie "+(i+1)+" :(.");
                    System.out.println("-----------------------------YOU DEAD-----------------------------");
                }

            }

        }

        System.out.println("GRACIÈS PER JUGAR AL MEU JOC.");

    }

}
